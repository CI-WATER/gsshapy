'''
********************************************************************************
* Name: Spatial Functions
* Author: Nathan Swain
* Created On: Sept 23, 2013
* Copyright: (c) Brigham Young University 2013
* License: BSD 2-Clause
********************************************************************************
'''

from geoalchemy2.functions import GenericFunction
from geoalchemy2 import Raster

class ST_AsGDALRaster(GenericFunction):
    '''
    '''
    name = 'ST_AsGDALRaster'